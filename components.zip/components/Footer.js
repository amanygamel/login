import {View,StyleSheet} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { Octicons } from '@expo/vector-icons';
import { Entypo } from '@expo/vector-icons';
export default function Footer(){
return(
<View style={styles.container}>

<View style={styles.leftContainer}>
  <AntDesign name="hearto" size={24} color="black" style={styles.Vmarign} />
  <Octicons name="comment" size={24} color="black" style={styles.Vmarign} />
  <Octicons name="share" size={24} color="black" style={styles.Vmarign} />
  </View>
  <Entypo name="forward" size={24} color="black" />
</View>

)


}

const styles = StyleSheet.create({

container:{flex:1,flexDirection:"row",justifyContent:"space-around",marginRight:5},
Vmarign:{
  marginHorizontal:6,
},
leftContainer:{
  flex:1,
  flexDirection:"row",


}

});