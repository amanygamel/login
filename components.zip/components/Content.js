import {Image} from "react-native";
const Content =({ImageSource})=>{
  return(
<Image  source={require('../assets/Amany.png')} style={{width:"100%",height:"90%"}} 
resizeMode="stretch"

/>


  )
}

export default Content;