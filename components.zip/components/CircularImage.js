import React from 'react';
import { Image } from 'react-native';
function CircularImage(imageSource, width, height){
 return ( <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/6bab1d011f020e5b8e85dedf1a835ceb'}}style={{ width:60, height:"100%", borderRadius: "50%",marginHorizontal:5     }}
      />
  );
}
export default CircularImage;